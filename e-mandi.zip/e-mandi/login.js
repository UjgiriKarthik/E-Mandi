function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function display(action) {
    if (action === 'submit') {
        const email = document.getElementById('inputEmail').value;
        const password = document.getElementById('inputPassword').value;

        if (email === '' || password === '') {
            alert('Please enter both email and password.');
        } else if (!isValidEmail(email)) {
            alert('Please enter a valid email address.');
        } else {
            alert('Login successful');
            window.location.href = 'project.html';
        }
    }
}
